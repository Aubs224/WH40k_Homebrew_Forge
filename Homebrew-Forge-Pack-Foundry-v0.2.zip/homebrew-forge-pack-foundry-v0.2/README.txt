HOMEbrew Forge Pack Foundry v0.2
================================

Open PackFoundry.html in a modern browser. No server or internet connection is required.

NEW IN V0.2
-----------
- Load a complete BSData repository ZIP downloaded from GitHub.
- Load an extracted repository folder.
- Discover JSON catalogues, library files, and MFM YAML recursively.
- Auto-detect faction catalogues and ignore obvious libraries/core files.
- Forge one faction or a combined all-factions Tome.
- Download a Tome bundle ZIP containing:
  * combined Tome JSON
  * separate faction packs
  * validation reports
  * matched points overlays
- Safer linked-profile traversal prevents broad armory groups from leaking unrelated weapons and abilities into a unit.
- Improved model-count and points-tier detection.
- Unit names containing [Legends] are marked as Legends.
- Improved Leader/Support attachment parsing.
- Outlier warnings flag units that resolve suspicious numbers of profiles.

RECOMMENDED FULL REPOSITORY WORKFLOW
------------------------------------
1. Download the BSData wh40k-11e repository using GitHub's Code > Download ZIP.
2. Open PackFoundry.html.
3. Drop the repository ZIP into the first drop area.
4. Select Full 40K Tome mode.
5. Review the detected faction catalogue checklist.
6. Keep Safe linked-profile resolution enabled.
7. Keep Aggressive linked-group resolution disabled.
8. Click Forge Tome.
9. Download the Tome bundle ZIP.
10. Install either the Tome JSON or selected faction packs through Homebrew Forge v1.1.

POINTS DATA
-----------
MFM YAML can be loaded separately, from an extracted MFM folder, or from a ZIP that contains YAML files. Matching YAML files are used to create detachable points overlays.

BROWSER SUPPORT
---------------
Repository ZIP import uses the browser DecompressionStream API. If the browser reports that ZIP decompression is unavailable, extract the repository and use Choose Folder instead.

DATA STATUS
-----------
Generated community packs should remain Provisional until reviewed. The validation report highlights missing points, incomplete profiles, unresolved links, suspicious profile counts, and other conversion concerns.
