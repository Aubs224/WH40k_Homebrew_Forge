HOMEBREW FORGE V1.1.1
====================

Run the app
-----------
1. Unzip the folder.
2. Double-click HomebrewForge.html.
3. Everything runs locally in your browser. No server, account, API key, or internet connection is required.

What changed in V1.1.1
----------------------
- Units can now be permanently deleted from the top toolbar or project library.
- Deletion includes a confirmation warning and removes the local IndexedDB record.
- Deleting the final unit leaves an empty project library instead of creating a replacement automatically.

What changed in V1.1
--------------------
- Data Pack Manager for installing, enabling, disabling, exporting, updating, and removing packages.
- Backward-compatible support for hbf-data-pack-1 files.
- New hbf-data-pack-2 format with:
  * multiple model profiles
  * multiple unit-size and points tiers
  * shared weapon and ability references
  * dependencies and version metadata
  * subfactions and supplements
  * leader and attachment relationships
  * wargear costs
  * source provenance, review status, Legends flags, and import warnings
- Separate hbf-points-overlay-1 packages for replacing points tiers and wargear costs.
- Existing V1 projects are migrated automatically when opened or imported.
- PDF and print exports now include multiple profiles, points tiers, source metadata, and import notes.

Included examples
-----------------
- examples/structured-demo-pack-v2.json
- examples/structured-demo-points-overlay.json

The examples are already built into the app, but the external files are included as templates for database work.

Important
---------
Balance estimates are heuristic and proxy-relative. They are intended to support opponent review and playtesting, not to certify tournament legality or official accuracy.
