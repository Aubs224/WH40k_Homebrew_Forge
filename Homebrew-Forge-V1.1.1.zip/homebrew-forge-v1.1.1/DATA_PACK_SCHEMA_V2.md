# Homebrew Forge data packages

## Faction pack: `hbf-data-pack-2`

```json
{
  "schema": "hbf-data-pack-2",
  "id": "stable-pack-id",
  "name": "Faction Pack Name",
  "version": "2026.07.1",
  "edition": "11th",
  "status": "Provisional",
  "dependencies": ["optional-core-pack-id"],
  "source": {
    "type": "Community dataset",
    "revision": "source commit or release"
  },
  "shared": {
    "weapons": {
      "weapon-id": {
        "id": "weapon-id",
        "name": "Weapon Name",
        "type": "Ranged",
        "range": "24",
        "a": "3",
        "skill": "3+",
        "s": 6,
        "ap": -1,
        "d": "2",
        "traits": "Sustained Hits 1"
      }
    },
    "abilities": {
      "ability-id": {
        "id": "ability-id",
        "name": "Ability Name",
        "template": "Leader Buff",
        "range": 0,
        "frequency": "While attached",
        "text": "Original or user-supplied summary."
      }
    }
  },
  "factions": [
    {
      "id": "faction-id",
      "name": "Faction Name",
      "subfaction": "Optional supplement",
      "units": [
        {
          "id": "stable-unit-id",
          "name": "Unit Name",
          "role": "Character / Infantry",
          "status": "Human Reviewed",
          "legends": false,
          "keywords": ["Infantry", "Character", "Faction Name"],
          "modelProfiles": [
            {
              "id": "primary-model",
              "name": "Primary Model",
              "primary": true,
              "baseSize": "40 mm",
              "stats": {
                "m": "6",
                "t": 5,
                "sv": "3+",
                "w": 5,
                "ld": "6+",
                "oc": 1,
                "inv": "5+",
                "fnp": ""
              }
            }
          ],
          "pointsOptions": [
            {
              "id": "standard",
              "label": "1 model",
              "models": 1,
              "points": 95
            }
          ],
          "weapons": ["weapon-id"],
          "abilities": ["ability-id"],
          "wargearOptions": ["Describe a replacement or option."],
          "wargearCosts": {"Optional item": 10},
          "leader": ["May lead Example Squad."],
          "attachmentTargets": ["Example Squad"],
          "transport": ["Counts as 2 models when embarked."],
          "importWarnings": [],
          "source": {
            "id": "source-unit-id",
            "catalogue": "source catalogue",
            "revision": "source revision"
          }
        }
      ]
    }
  ]
}
```

Weapons and abilities may be embedded objects instead of shared string references.

## Points overlay: `hbf-points-overlay-1`

```json
{
  "schema": "hbf-points-overlay-1",
  "id": "stable-overlay-id",
  "name": "Points Update Name",
  "version": "2026.07",
  "edition": "11th",
  "status": "Human Reviewed",
  "appliesTo": ["stable-pack-id"],
  "source": {"effectiveDate": "2026-07-15"},
  "entries": {
    "stable-unit-id": {
      "pointsOptions": [
        {"id": "standard", "label": "1 model", "models": 1, "points": 100}
      ],
      "wargearCosts": {"Optional item": 15}
    }
  }
}
```

An enabled overlay is applied when its `appliesTo` list contains the faction pack ID or name. Multiple enabled overlays are applied in package order, with later matching values replacing earlier ones.

## Review statuses

Suggested values:

- Generated
- Machine Checked
- Human Reviewed
- Play Verified
- Provisional
- Outdated

These labels are informational and appear in the package report and exported datasheet.
